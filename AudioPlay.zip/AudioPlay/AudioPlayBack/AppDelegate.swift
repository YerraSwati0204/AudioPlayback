//
//  AppDelegate.swift
//  AudioPlayBack
//
//  Created by Swati Yerra on 04/09/19.
//  Copyright © 2019 Swati Yerra. All rights reserved.
//

import Cocoa

@NSApplicationMain
class AppDelegate: NSObject, NSApplicationDelegate {


    var audioObject = [[String: Any]]()
    
    func applicationDidFinishLaunching(_ aNotification: Notification) {
//        let defaults = UserDefaults.standard
//        let dictionary = defaults.dictionaryRepresentation()
//        dictionary.keys.forEach { key in
//            defaults.removeObject(forKey: key)
//        }
        // Insert code here to initialize your application
        guard let audioObject = UserDefaults.standard.object(forKey: "SavedDict") as? [[String: Any]] else {
            return
        }
        self.audioObject = audioObject
    }

    func applicationWillTerminate(_ aNotification: Notification) {
        // Insert code here to tear down your application
    }


}

