//
//  CustomWhiteBackgroundView.swift
//  AudioPlayBack
//
//  Created by Swati Yerra on 04/09/19.
//  Copyright © 2019 Swati Yerra. All rights reserved.
//

import Cocoa

class CustomWhiteBackgroundView: NSView {

    override func draw(_ dirtyRect: NSRect) {
        super.draw(dirtyRect)
        self.wantsLayer = true
        self.layer?.backgroundColor = NSColor(calibratedRed: 255/255, green: 255/255, blue: 255/255, alpha: 0.7).cgColor
    }
    
}
