//
//  Audio.swift
//  AudioPlayBack
//
//  Created by Swati Yerra on 04/09/19.
//  Copyright © 2019 Swati Yerra. All rights reserved.
//

import Foundation

class Audio: NSObject {
    @objc dynamic var audioName: String = ""
    @objc dynamic var artist: String = ""
    @objc dynamic var duration: String = ""
    @objc dynamic var audioPath: String = ""
    
    func initializingValues(dict: [[String:Any]]) -> [Audio] {
        var audio = [Audio]()
        for items in dict {
            let audioObj = Audio()
            audioObj.audioName = items["audioName"] as? String ?? ""
            audioObj.audioPath = items["audioPath"] as? String ?? ""
            audioObj.artist = items["artist"] as? String ?? ""
            audioObj.duration = items["duration"] as? String ?? ""
            audio.append(audioObj)
        }
        return audio
    }
    
    func modelTodict(model:[Audio]) -> [[String:Any]] {
        var dict =  [String: Any]()
        var arr = [[String: Any]] ()
        
        for items in model {
            dict["audioName"] = items.audioName
            dict["audioPath"] = items.audioPath
            dict["artist"] = items.artist
            dict["duration"] = items.duration
            arr.append(dict)
        }
        return arr
    }
}
