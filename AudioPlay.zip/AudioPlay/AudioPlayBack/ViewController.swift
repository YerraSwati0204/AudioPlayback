//
//  ViewController.swift
//  AudioPlayBack
//
//  Created by Swati Yerra on 04/09/19.
//  Copyright © 2019 Swati Yerra. All rights reserved.
//

import Cocoa
import AVFoundation
import MediaPlayer

class ViewController: NSViewController,NSTableViewDelegate {
    
    @IBOutlet weak var playPauseAudio: NSButton!
    @IBOutlet weak var audioTableView: NSTableView!
    @objc dynamic var audioList = [Audio]()
    @objc dynamic var selectedAudioObject : Audio = Audio()
    var audioPlayer: AVAudioPlayer!
    var hasBeenPaused = false
    var filesList: [URL] = []
    let defaults = UserDefaults.standard
    var dictToSave = [[String:Any]]()

    var selectedFolder: URL? {
        didSet {
            if let selectedFolder = selectedFolder {
                self.audioTableView.reloadData()
                self.audioTableView.scrollRowToVisible(0)
                view.window?.title = selectedFolder.path
            } else {
                view.window?.title = "Rocket Player"
            }
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let appDelegate = NSApplication.shared.delegate as! AppDelegate
        DispatchQueue.main.async {
            let newAudioObject = self.selectedAudioObject.initializingValues(dict: appDelegate.audioObject)
            self.audioList = newAudioObject
        }
        self.hasBeenPaused = false
    }

    func playSoundWith(fileName: String, fileExtension: String) -> Void {
        //Gathering audio file source location
        let audioSourceURL: URL!
        audioSourceURL = URL(fileURLWithPath: self.selectedAudioObject.audioPath)
        //once audio source url gathers location of Audio file we need to check whether it contains an address or NIL value
        if audioSourceURL == nil {
            print("Requested song cannot be played")
        }else {
            //create audio player for the requested track
            do {
                audioPlayer = try AVAudioPlayer.init(contentsOf: audioSourceURL)
                audioPlayer.prepareToPlay()
                audioPlayer.play()
                print("Playing the current song: \(fileName)")
            }catch {
                print(error)
            }
        }
        
    }

    @IBAction func forwardAction(_ sender: Any) {
        if self.audioTableView.selectedRow != -1 {
            let selectedAudio: String = (self.audioList[self.audioTableView.selectedRow + 1] as Audio).audioName
            self.audioTableView.selectRowIndexes(NSIndexSet(index: self.audioTableView.selectedRow + 1) as IndexSet, byExtendingSelection: false)
            playSoundWith(fileName: selectedAudio, fileExtension: "m4a")
        }
    }
    
    @IBAction func backwardAction(_ sender: Any) {
        if self.audioTableView.selectedRow + 1 != -1 && self.audioTableView.selectedRow + 1 <= self.audioList.count {
            let selectedAudio: String = (self.audioList[self.audioTableView.selectedRow - 1] as Audio).audioName
            self.audioTableView.selectRowIndexes(NSIndexSet(index: self.audioTableView.selectedRow - 1) as IndexSet, byExtendingSelection: false)
            playSoundWith(fileName: selectedAudio, fileExtension: "m4a")
        }
    }
    
    @IBAction func restartButtonAction(_ sender: Any) {
        if audioPlayer.isPlaying || hasBeenPaused {
            audioPlayer.stop()
            audioPlayer.currentTime = 0
            audioPlayer.play()
        } else  {
            audioPlayer.play()
        }
    }
    
    @IBAction func playPauseButtonAction(_ sender: Any) {
        if (hasBeenPaused == false) {
            playPauseAudio.image = NSImage(imageLiteralResourceName: "pause")
            playSoundWith(fileName: self.selectedAudioObject.audioName, fileExtension: "m4a")
            hasBeenPaused = true
        }else {
            playPauseAudio.image = NSImage(imageLiteralResourceName: "play")
            if audioPlayer != nil {
                if audioPlayer.isPlaying {
                    audioPlayer.pause()
                    hasBeenPaused = true
                } else {
                    hasBeenPaused = false
                }
            }else {
                let alert = NSAlert()
                alert.informativeText = "Play an Audio"
                alert.alertStyle = NSAlert.Style.warning
                alert.addButton(withTitle: "Close")
                alert.runModal()
            }
        }
    }
    
    func tableViewSelectionDidChange(_ notification: Notification) {
        let tableView = notification.object as? NSTableView
        if tableView?.selectedRow != nil && tableView?.selectedRow != -1 {
            selectedAudioObject = self.audioList[(tableView?.selectedRow)!] as Audio
        }
    }
    
    @IBAction func deleteAction(_ sender: Any) {
        if self.audioTableView.selectedRow != -1 {
            self.audioList.remove(at: self.audioTableView.selectedRow)
            self.dictToSave = self.selectedAudioObject.modelTodict(model: self.audioList)
            self.defaults.set(self.dictToSave, forKey: "SavedDict")
        }
    }
    
    @IBAction func addAction(_ sender: Any) {
        let openPanel = NSOpenPanel()
        let audio = Audio()
        openPanel.allowsMultipleSelection = true
        openPanel.canChooseDirectories = false
        openPanel.canCreateDirectories = false
        openPanel.canChooseFiles = true
        openPanel.begin { (result) -> Void in
            if result.rawValue == NSApplication.ModalResponse.OK.rawValue {
                self.selectedFolder = openPanel.url
                do {
                    // "/Users/swati.y/Desktop/PurpleRain.m4a"
                    let url = URL(fileURLWithPath: self.selectedFolder!.path)
                    let playerItem = AVPlayerItem(url: url)
                    let metadataList = playerItem.asset.commonMetadata
                    for item in metadataList {
                        if item.commonKey!.rawValue == "title" {
                            self.selectedAudioObject.audioName = (item.stringValue)!
                        }
                        if item.commonKey!.rawValue == "artist" {
                            self.selectedAudioObject.artist = (item.stringValue)!
                        }
                    }
                    
                    let player = AVPlayer(playerItem: AVPlayerItem(url: url))
                    let durationTime = CMTimeGetSeconds((player.currentItem?.asset.duration)!)

                    let audioName = (self.selectedFolder?.path.components(separatedBy: "/").last)?.components(separatedBy: ".").first
                    audio.audioName = audioName!
                    audio.audioPath = self.selectedFolder!.path
                    audio.artist =  self.selectedAudioObject.artist
                    audio.duration = "\(Double(durationTime/60))"
                    self.audioList.append(audio)
                    self.dictToSave = self.selectedAudioObject.modelTodict(model: self.audioList)
                    self.defaults.set(self.dictToSave, forKey: "SavedDict")
                }
            }
        }
    }
}

