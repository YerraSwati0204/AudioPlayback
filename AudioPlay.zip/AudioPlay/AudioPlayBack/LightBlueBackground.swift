//
//  LightBlueBackground.swift
//  AudioPlayBack
//
//  Created by Swati Yerra on 04/09/19.
//  Copyright © 2019 Swati Yerra. All rights reserved.
//

import Cocoa

class LightBlueBackground: NSView {

    override func draw(_ dirtyRect: NSRect) {
        super.draw(dirtyRect)
        // Drawing code here.
        self.wantsLayer = true
        self.layer?.backgroundColor = NSColor(calibratedRed: 170/255, green: 216/255, blue: 275/255, alpha: 0.3).cgColor
    }
    
}
